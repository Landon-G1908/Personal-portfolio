function scollToSection(sectionId) {
  var element = document.getElementById(sectionId);

  element.scrollIntoView({ behavior: 'smooth'});
}

const carouselSlide = document.querySelector('.carousel-slide');

const carouselItem = document.querySelectorAll('.carousel-item');

const prevBtn = document.getElementById('#prevBtn');
const nextBtn = document.getElementById('#nextBtn');
let counter = 0;

function updateCarousel(){
  const size = carouselItem[0].clientWidth;
  
  carouselSlide.style.transition = 'none';

  carouselSlide.style.transform = 'translateX('+(-size * counter)+'px)';

window.addEventListener('resize', updateCarousel);

updateCarousel();

nextBtn.addEventListener('click',() => {

  if (counter >= carouselItem.length - 1) {
    counter = -1;
  }

carouselSlide.style.transition = "transform 0.5s ease-in-out";

counter++;

const size = carouselItem[0].clientWidth;

carouselSlide.style.transform = 'translateX('+(-size * counter) + 'px)';

prevBtn.addEventListener('click', () => {
    if (counter <= 0) 
        counter = carouselItem.length;
}

  carouselSlide.style.transition = "transform 0.5s ease-in-out";

  counter--;

  const size = carouselItem[0].clientWidth;

  carouselSlide.style.transform = 'translateX(' + (-size * counter) + 'px)';












                         

  
})}